package org.intracode.sendmessage

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //bind objects
        val btngo = findViewById<Button>(R.id.btn)
        val sendStuff = findViewById<EditText>(R.id.textMessage)

        btngo.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, Main2Activity::class.java)

            intent.putExtra("GREETINGS_FOLKS", sendStuff.text.toString())
            startActivity(intent)

        })


        findViewById<View>(android.R.id.content).setOnTouchListener { _,_ ->
            hideKeyboard()
            false
        }

    }


    fun hideKeyboard() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(currentFocus!!.windowToken, 0)
        } catch (e: Exception) {
            // TODO: handle exception
        }

    }

}